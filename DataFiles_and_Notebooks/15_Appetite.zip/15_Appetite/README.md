# simple_scraper.py

An example of doing web scraping using just the standard library, as well as
BeautifulSoup

# appetite.py

An example of making a simple sqlite database and sending out emails

# helloX.py files

These are simple Flask examples for the Python Bootcamp

To follow along, go through each of the helloX.py files, starting with hello1.py

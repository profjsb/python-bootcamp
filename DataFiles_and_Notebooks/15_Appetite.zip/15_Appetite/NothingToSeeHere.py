# UC Berkeley users. To use the bmail (Google) smtp server, you will need to
# create a Google Key: see this website for details
# https://kb.berkeley.edu/campus-shared-services/page.php?id=27226
username = ''
password = ''
